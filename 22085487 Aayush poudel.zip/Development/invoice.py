
def rent_invoice(customer_name, address, phone_number, rent_duration, rent_orders, rent_date):
    """
    Generate an invoice for a customer's rented land(s).
    """
    rent_invoice = "\n"+"---" * 37 +"\n"
    rent_invoice += "     "*10+"Land Rent Invoice"
    rent_invoice += "\n"+"---" * 37 +"\n\n"
    rent_invoice += "Customer Name: " + customer_name + "\n"
    rent_invoice += "Current Address: " + address + "\n"
    rent_invoice += "Phone Number: " + str(phone_number) + "\n"
    rent_invoice += "Rent Date: " + str(rent_date) + "\n"
    rent_invoice += "Rent Duration: " + str(rent_duration) + " month(s)\n\n"
    rent_invoice += "---" * 37 +"\n"
    rent_invoice += "| S.N. | Kitta Number      | City                  | Direction          | Anna             | Price            |"
    rent_invoice += "\n"+"---" * 37 +"\n"
    
    totalAmount = 0 
    sn_num = 1 # Initialize order number
    for order in rent_orders:  
        kitta_number = order[0] 
        city = order[1]
        direction = order[2]
        anna = order[3]
        price= float(order[4]) * rent_duration 
        totalAmount += float(price)
        rent_invoice += (
        "| " + str(sn_num) + " " * (5 - len(str(sn_num))) +
        "| " + str(kitta_number) + " " * (18 - len(str(kitta_number))) +
        "| " + city + " " * (22 - len(city)) +
        "| " + direction + " " * (19 - len(direction)) +
        "| " + str(anna) + " " * (17 - len(str(anna))) +
        "| Rs " + str(float(price)) + " " * (14 - len(str(float(price)))) + "|" + "\n"
        )
        rent_invoice += "---" * 37 +"\n" 
        sn_num += 1 # Increment order number

    
    rent_invoice += "\nTotal Amount: Rs " + str(totalAmount)
    rent_invoice +=   "\n\n"+"---" * 37 + "\n\n"
    rent_invoice += "Terms and Conditions:\n\n"

    rent_invoice += "1. The rental period shall be mutually agreed upon between TechnoPropertyNepal and the Customer. The minimum\n"
    rent_invoice += "   rental duration is one month.\n"
    rent_invoice += "2. The Customer agrees to pay the rental amount as per the agreed terms. Payment shall be made in Nepalese\n" 
    rent_invoice += "   Rupee (NPR) and should be settled in advance before the commencement of each rental period.\n"
    rent_invoice += "3. If a client is unable to renew the contract on time and is late to return the land, in such case a fine should\n"
    rent_invoice += "   be applied on a monthly basis.\n\n"   
    
    rent_invoice += "Thank you for choosing us!\n\n"
    rent_invoice += "For any requests, kindly reach us at AayushPoudel10@gmail.com\n\n"
    rent_invoice += "---" * 37 +"\n" 

    return rent_invoice

def return_invoice(customer_name, address, phone_number, return_duration, return_orders, return_date, total_late_fine, rent_duration):
    """
    Generate an invoice for a customer's returned land(s).
    """
    return_invoice = "\n" + "---" * 37 + "\n"
    return_invoice += "     " * 10 + "Land Return Invoice"
    return_invoice += "\n" + "---" * 37 + "\n\n"
    return_invoice += "Customer Name: " + customer_name + "\n"
    return_invoice += "Current Address: " + address + "\n"
    return_invoice += "Phone Number: " + str(phone_number) + "\n"
    return_invoice += "Return Date: " + str(return_date) + "\n"
    return_invoice += "Return Duration: " + str(return_duration) + " month(s)\n\n"
    return_invoice += "---" * 37 + "\n"
    return_invoice += "| S.N. | Kitta Number      | City                  | Direction          | Anna             | Price            |\n"
    return_invoice += "---" * 37 + "\n"

    totalAmount = 0
    sn_num = 1  # Initialize order number

    for order in return_orders:
        kitta_number = order[0] 
        city = order[1]
        direction = order[2]
        anna = order[3]
        price = float(order[4]) * return_duration
        totalAmount += float(order[4]) * rent_duration
        return_invoice += (
            "| " + str(sn_num) + " " * (5 - len(str(sn_num))) +
            "| " + str(kitta_number) + " " * (18 - len(str(kitta_number))) +
            "| " + city + " " * (22 - len(city)) +
            "| " + direction + " " * (19 - len(direction)) +
            "| " + str(anna) + " " * (17 - len(str(anna))) +
            "| Rs " + str(price) + " " * (14 - len(str(price))) + "|\n"
        )
        return_invoice += "---" * 37 + "\n"
        sn_num += 1  # Increment order number

    if total_late_fine>0:
        return_invoice += "\nTotal Fine: Rs " + str(total_late_fine) + "\n"
    total=str(totalAmount+total_late_fine)
    return_invoice += "\nTotal Amount: Rs " + str(total) + "\n"
    return_invoice +=   "\n"+"---" * 37 + "\n\n"
    return_invoice += "Terms and Conditions:\n\n"

    return_invoice += "1. The rental period shall be mutually agreed upon between TechnoPropertyNepal and the Customer. The minimum\n"
    return_invoice += "   rental duration is one month.\n"
    return_invoice += "2. The Customer agrees to pay the rental amount as per the agreed terms. Payment shall be made in Nepalese\n" 
    return_invoice += "   Rupee (NPR) and should be settled in advance before the commencement of each rental period.\n"
    return_invoice += "3. If a client is unable to renew the contract on time and is late to return the land, in such case a fine should\n"
    return_invoice += "   be applied on a monthly basis.\n\n"    
    return_invoice += "Thank you for returning the land(s)!\n\n"
    return_invoice += "For any requests, kindly reach us at AayushPoudel10@gmail.com\n\n"
    return_invoice += "---" * 37 + "\n"

    return return_invoice