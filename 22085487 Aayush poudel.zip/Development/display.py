def display():
    """
    Display the main menu of the Rental System.
    """
    print("""
──────────────────────────────────────────────────────────────────────────────────────────────────────────────
                                        Welcome To The Rental System 
──────────────────────────────────────────────────────────────────────────────────────────────────────────────
          
Please enter one of the below options:
    
1. Display Available Land
2. Rent Land
3. Return Land
4. Exit
"""+"\n")
    
def print_data(data):
    print("\n" + "───" * 36 + "──")
    print("   " * 15 + "Available Lands for Renting")
    print("───" * 36 + "──" + "\n")
    print("───" * 36 + "──")
    print("│ Kitta Number │ City                  │ Direction         │ Anna          │ Price       │ Available Status  │")
    print("───" * 36 + "──")

    for i in range(len(data)):
        row = data[i]
        kitta_number = row[0]
        city = row[1]
        direction = row[2]
        anna = row[3]
        price = row[4]
        status = row[5]

        data_line = (
            "│ " + str(kitta_number) + "  " * (8 - len(str(kitta_number))) +
            "│ " + city + " " * (22 - len(city)) +
            "│ " + direction + " " * (18 - len(direction)) +
            "│ " + str(anna) + " " * (14 - len(str(anna))) +
            "│ Rs " + str(price) + " " * (9 - len(str(price))) +
            "│ " + status + " " * (17 - len(status)) + " │"
        )

        print(data_line)

    print("───" * 36 + "──" + "\n")
