import operation

def write_rent_invoice(rent_invoice, customer_name):
    rent_invoice_filename = 'Rent' + '_' + customer_name  + '_'  + str(operation.date_and_time()) + '.txt'
    file = open(rent_invoice_filename, "w")
    file.write(rent_invoice)
    file.close()

def write_return_invoice(return_invoice,customer_name):
    return_invoice_filename = 'Return' + '_' + customer_name  + '_'  + str(operation.date_and_time()) + '.txt'
    file = open(return_invoice_filename, "w")
    file.write(return_invoice)
    file.close()

def write_data(data):
    # Write the updated data to the data.txt file
    file = open("data.txt", "w")
    for row in data:
        file.write(",".join(row) + "\n") 
    file.close()









   
    
