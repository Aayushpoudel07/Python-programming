def read_data():
    file = open("data.txt", "r")
    data = []
    for land in file.readlines():
        data.append(land.replace("\n", "").split(","))
    file.close()
    return data

