import datetime
def date_and_time():
    year = str(datetime.datetime.now().year)
    month = str(datetime.datetime.now().month)
    day = str(datetime.datetime.now().day)
    hour = str(datetime.datetime.now().hour)
    minute = str(datetime.datetime.now().minute)
    second = str(datetime.datetime.now().second)
    time = year + "-" + month + "-" + day +  "_" + hour +  "-" + minute +  "-" + second

    return time


