import display
import read_data
import write_data
import function
import datetime
import invoice

def run():
    data = read_data.read_data()

    while True:
        try:
            display.display()
            option = int(input("Enter your Option (1, 2, 3 or 4): "))
            
            if option == 1:
                display.print_data(data)

            elif option == 2:
                print("\n\nNamaste! You are renting land.")
                print("\n"+"───" * 36 + "──" )
                print("     "*7+"Please specify your information to us.")
                print("───" * 36 + "──" +"\n")
                while True:
                    customer_name = input("\nEnter your name: ")                        
                    if len(customer_name) == 0:
                        print("\nInvalid input! Please enter a valid name.")
                    else:
                        break
                while True:
                    address = input("\nEnter your address: ")
                    if len(address) == 0:
                        print("\nInvalid input! Please enter a valid address.")
                    else:
                        break
                while True:
                    try:
                        phone_number = int(input("\nEnter your phone number: "))
                        break
                    except ValueError:                     
                        print("\nInvalid input! Please enter a valid number.")
                
                
                # Calling rent_land function.
                rent_orders=function.rent_land(data)
                rent_duration=0
                while True:
                    try:
                        rent_duration = int(input("\nEnter duration of rent (in months): "))
                        if rent_duration <= 0:
                            print("\nDuration must be a positive integer.")
                        else:
                            print("\nLands rented successfully.")
                            break  # Exit the duration input loop
                    except ValueError:
                        print("\nInvalid input! Please enter a valid duration.")

                rent_date = datetime.datetime.now().date() 
                rent_invoice = invoice.rent_invoice(customer_name, address, phone_number, rent_duration, rent_orders, rent_date)
                print(rent_invoice)
                write_data.write_rent_invoice(rent_invoice, customer_name)

                # Update status of rented lands and write updated data to data.txt
                for row in rent_orders:
                    kitta_number = int(row[0])
                    for data_row in data:
                        if int(data_row[0]) == kitta_number:
                            data_row[5] = "Not Available"
                    
                write_data.write_data(data)

            elif option == 3:                
                
                print("\n\nNamaste! You are returning land.")
                print("\n"+"───" * 36 + "──" )
                print("     "*7+"Please specify your information to us.")
                print("───" * 36 + "──" +"\n")
                while True:
                    customer_name = input("\nEnter customer name: ")                        
                    if len(customer_name) == 0:
                        print("\nInvalid input. Please enter a valid name.")
                    else:
                        break
                while True:
                    address = input("\nEnter current address: ")
                    if len(address) == 0:
                        print("\nInvalid input. Please enter a valid address.")
                    else:
                        break
                while True:
                    try:
                        phone_number = int(input("\nEnter phone number: "))
                        break
                    except ValueError:                     
                        print("\nInvalid input. Please enter a valid number.")

                return_orders=function.return_land(data,rent_orders)

                return_duration=0
                while True:
                    try:
                        return_duration = int(input("\nEnter duration of return (in months): "))
                        if return_duration <= 0:
                            print("\nDuration must be a positive integer.")
                        else:
                            print("\nLands returned successfully.")
                            break  # Exit the duration input loop
                    except ValueError:
                        print("\nInvalid input. Please enter a valid duration.")

                total_late_fine=0
                for row in return_orders:
                    price=int(row[4])                    
                    if return_duration>rent_duration:
                        late_fine=(return_duration-rent_duration)*price # Assuming price is for per month rented
                    else:
                        late_fine=0                    
                    total_late_fine+=late_fine

                return_date=datetime.datetime.now().date() 
                return_invoice = invoice.return_invoice(customer_name, address, phone_number, return_duration, return_orders, return_date, total_late_fine, rent_duration)
                print(return_invoice)
                write_data.write_return_invoice(return_invoice,customer_name)

                # Update status of rented lands and write updated data to data.txt
                for row in return_orders:
                    kitta_number = int(row[0])
                    for data_row in data:
                        if int(data_row[0]) == kitta_number:
                            data_row[5] = "Available"
                write_data.write_data(data)

            elif option == 4:
                print("\nThank You for using this system.")
                break

            else:
                print("\nPlease enter a valid number.")

                
        except ValueError:
            print("\nInvalid input! Please enter a vaild number.")

run()