
import display

def rent_land(data):
    display.print_data(data)
    rent_orders = []
    while True:
        try:
            num = int(input("\nEnter kitta number to rent: "))
            found = False  # Flag to track if the kitta number is found
            for row in data:
                if int(row[0]) == num:
                    found = True
                    if row[5] == "Available":
                        rent_orders.append(row)
                        break  # Exit the for loop after renting the land
                    else:
                        print("\nThis land is not available for rent.")                        
                        break  # Exit the for loop after invalid land
            if not found:
                print("\nInvalid kitta number. Please enter a valid kitta number.")
                continue  # Continue to the next iteration of the main loop
            display.print_data(data)
            print("\nDo you want to rent more lands?")
            while True:
                more_rent = input("(Please respond with 'y' for yes or 'n' for no): ").lower()
                if more_rent == 'n': 
                    return rent_orders
                    
                elif more_rent == 'y':
                    
                    break  # Exit the main loop
                else:
                    print("\nInvalid input. Please enter 'y' or 'n'.\n")
        
        except ValueError:
            print("\nInvalid input. Please enter a valid kitta number.")


def return_land(data, rent_orders):
    display.print_data(data)
    return_orders = []
    while True:
        try:
            num = int(input("\nEnter kitta number to return: "))
            found = False  # Flag to track if the kitta number is found
            for row in rent_orders:
                if int(row[0]) == num:
                    found = True
                    rent_orders.remove(row)  # Remove the returned land from rent_orders
                    for land in data:
                        if int(land[0]) == num:
                            land[5] = "Available"  # Mark the land as available again
                            return_orders.append(land)  # Add the returned land to return_orders
                            break
                    break
            if not found:
                print("\nInvalid kitta number. Please enter a valid kitta number.")
                continue  # Continue to the next iteration of the main loop
                
            display.print_data(data)
            print("\nDo you want to return more lands?")
            while True:
                more_return = input("(Please respond with 'y' for yes or 'n' for no): ").lower()
                if more_return == 'n':
                    return return_orders
                    
                elif more_return == 'y':
                    break  # Exit the main loop

                else:
                    print("\nInvalid input. Please enter 'y' or 'n'.\n")

        except ValueError:
            print("\nInvalid input. Please enter a valid kitta number.")

    
                
